#!/usr/bin/env python3
import os
import json
import re
from pathlib import Path

def extract_conversations(html_dir):
    conversations = []
    
    for html_file in Path(html_dir).glob('*.html'):
        try:
            with open(html_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
            # Try to find JSON data embedded in script tags
            json_matches = re.findall(r'window\.__INITIAL_STATE__\s*=\s*({.*?});', content, re.DOTALL)
            for match in json_matches:
                try:
                    data = json.loads(match)
                    conversations.append({
                        'file': str(html_file),
                        'data': data
                    })
                except:
                    pass
            
            # Extract visible text conversations
            text_matches = re.findall(r'<div[^>]*conversation[^>]*>(.*?)</div>', content, re.IGNORECASE | re.DOTALL)
            if text_matches:
                conversations.append({
                    'file': str(html_file),
                    'text': text_matches
                })
        except Exception as e:
            print(f"Error processing {html_file}: {e}")
    
    return conversations

# Extract from both directories
bard_convos = extract_conversations('bard_ghosts')
gemini_convos = extract_conversations('gemini_captures')

# Save results
with open('extracted_conversations.json', 'w') as f:
    json.dump({
        'bard': bard_convos,
        'gemini': gemini_convos,
        'total_files': len(bard_convos) + len(gemini_convos)
    }, f, indent=2)

print(f"Extracted {len(bard_convos)} Bard and {len(gemini_convos)} Gemini conversations")
