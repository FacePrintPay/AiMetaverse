#!/usr/bin/env bash
set -euo pipefail

SRC_DIR="$HOME"
DEST="user@server:/path/to/backup"
LOG_DIR="$HOME/backup-logs"
mkdir -p "$LOG_DIR"

TS=$(date '+%Y-%m-%d_%H-%M-%S')
LOG_FILE="$LOG_DIR/backup_$TS.log"

echo "[*] Starting backup at $TS" | tee -a "$LOG_FILE"
echo "[*] Source: $SRC_DIR" | tee -a "$LOG_FILE"
echo "[*] Dest:   $DEST" | tee -a "$LOG_FILE"

# Exclude some noisy dirs
rsync -avz --delete   --exclude='.cache'   --exclude='storage'   --exclude='backup-logs'   "$SRC_DIR/" "$DEST" | tee -a "$LOG_FILE"

echo "[✓] Backup finished at $(date '+%Y-%m-%d_%H-%M-%S')" | tee -a "$LOG_FILE"
