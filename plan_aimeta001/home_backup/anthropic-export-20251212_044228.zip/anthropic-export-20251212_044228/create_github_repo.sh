#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

REPO_NAME="${REPO_NAME:-claude-artifacts-export}"
REPO_DIR="$HOME/$REPO_NAME"

echo "Creating repo folder: $REPO_DIR"
mkdir -p "$REPO_DIR"
cd "$REPO_DIR"

git init >/dev/null

mkdir -p scripts docs exports/{conversations,artifacts} config .github/workflows

cat > README.md <<'README'
# Claude Export Vault

This repo stores exported Claude conversations, artifacts, and supporting notes.

## Layout
- exports/conversations/  → exported Markdown/JSON and/or full export zips
- exports/artifacts/      → downloaded artifacts
- docs/                   → notes, summaries, indexes
- scripts/                → helper scripts

## How to add exports
Copy files into exports/ then commit + push.

README

echo "✅ Repo skeleton ready at: $REPO_DIR"
echo "Next: copy your export files into exports/, then commit + push."
