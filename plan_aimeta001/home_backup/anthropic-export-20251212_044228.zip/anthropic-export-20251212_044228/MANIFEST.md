# Claude Export Runbook (Anthropic)

Generated: Fri Dec 12 04:42:28 EST 2025

## What this folder is
This is a **local export workspace** for backing up:
- Claude conversation exports (downloaded via Claude UI)
- Claude account full data export (requested from settings)
- Any artifacts you manually copy/download

## Where to export from Claude
### Export a single conversation
1. Open Claude in browser: https://claude.ai
2. Open the conversation you want
3. Menu (⋯) → **Export conversation** (Markdown/JSON)
4. Save into:
   - /data/data/com.termux/files/home/anthropic-export-20251212_044228/conversations/

### Request your full data export (all conversations)
1. Go to: https://claude.ai/settings
2. Privacy & Data → **Request data export**
3. Save the delivered ZIP into:
   - /data/data/com.termux/files/home/anthropic-export-20251212_044228/conversations/

## Local folders
- conversations/  → exported .md/.json or full export zip
- artifacts/      → any downloaded artifacts
- notes/          → your hand notes or evidence memos

## Optional: turn this into a GitHub repo
Run:
  bash /data/data/com.termux/files/home/anthropic-export-20251212_044228/create_github_repo.sh

